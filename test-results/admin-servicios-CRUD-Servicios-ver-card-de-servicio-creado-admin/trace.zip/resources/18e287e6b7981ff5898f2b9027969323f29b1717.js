(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_features_35f3812e._.js",
  "static/chunks/node_modules_4a74da15._.js"
],
    source: "dynamic"
});
