(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_features_8d60c20c._.js",
  "static/chunks/node_modules_ebfcaec1._.js"
],
    source: "dynamic"
});
