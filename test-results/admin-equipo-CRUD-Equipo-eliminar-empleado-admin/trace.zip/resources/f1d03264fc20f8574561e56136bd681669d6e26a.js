(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_features_c2ee778d._.js",
  "static/chunks/node_modules_5e070a40._.js"
],
    source: "dynamic"
});
