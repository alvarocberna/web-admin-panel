(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_c42dfbc0._.js",
  "static/chunks/node_modules_next_99e9ab92._.js",
  "static/chunks/node_modules_@fortawesome_fontawesome-svg-core_index_mjs_79b8db01._.js",
  "static/chunks/node_modules_@fortawesome_free-solid-svg-icons_index_mjs_e676fced._.js",
  "static/chunks/node_modules_@fortawesome_free-regular-svg-icons_index_mjs_2479eea4._.js",
  "static/chunks/node_modules_gsap_f48a6384._.js",
  "static/chunks/node_modules_@dnd-kit_core_dist_core_esm_3ed85ea0.js",
  "static/chunks/node_modules_b9aa71c2._.js"
],
    source: "dynamic"
});
